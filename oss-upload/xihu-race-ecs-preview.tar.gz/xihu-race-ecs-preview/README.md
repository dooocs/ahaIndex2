# 西湖飞车 ECS 联机预览包

本包是 PR #106 的自动匹配原型（代码版本 1b6446af812f9437720b47f2fc18498c05ba6731），赛道检查门和发车位从主分支 8b3a6133a3e0c5428aa1677b3e27aed3f6b303ea 导出。本包仅限 2–4 人自动匹配验收，无邀请码房间、无正式 /race 入口、无持久化，代码不会写入 Supabase。100 m/s 是预览判定阈值，基于默认 84.9 m/s 喷气上限留余量，不能视为实车验证或防作弊证明。/test 提供测试椭圆赛道，不是正式西湖界面。

## ECS 验收启动

1. 将整个归档解包到一个新的有写权限的部署目录。用现有专用非 root 游戏服务账号执行，不覆盖除本次服务外的目录。
2. 安装前在 ECS 检查 Node 版本（推荐现有 Node 22 或 24）及端口占用，例如 `ss -ltn 'sport = :2567'`。若端口或同名 PM2 进程已存在，先核对用途，不要停掉未知服务。
3. 在解包后的 `xihu-race-ecs-preview` 目录运行：
   ```sh
   npm ci --omit=dev --ignore-scripts --no-audit --no-fund
   cp .env.example .env
   pm2 start ecosystem.config.cjs
   curl --fail --show-error --max-time 5 http://127.0.0.1:2567/health
   curl --fail --show-error --max-time 5 http://127.0.0.1:2567/status
   ```
   PM2 进程名是 `xihu-race-preview`。应用固定只监听本机 IPv4 环回，不更改 Caddy、安全组、网站或数据库。已有反代若指向该端口，再检查其公开 /health、/status 和两端 /test，不能只凭普通 HTTP 返回码断言 WSS 正常。已有反代若未指向该端口，先做本机验收，不要为了预览开放 2567。
4. 回滚只停止这个包启动的 `xihu-race-preview`，不影响其他进程。不要覆盖原部署或为预览自动保存整份 PM2 列表。

`npm test` 是内置赛道判定与本机 WebSocket 联机模拟。它不连接 ECS、线上网站或数据库。赛道重新导出需回到 ahaIndex2 完整源码树，验收包只带已经导出的数据。
